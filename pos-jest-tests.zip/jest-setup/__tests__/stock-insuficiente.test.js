/**
 * Pruebas: Stock insuficiente al vender (HU-05, HU-10, T-22, T-35)
 *
 * Verifica que el sistema rechace ventas cuando no hay suficiente
 * inventario de algun insumo requerido por la receta del producto.
 */

// Mock del cliente de Supabase antes de importar cualquier modulo que lo use
jest.mock('../src/config/supabase-client')

import supabase from '../src/config/supabase-client'
import { checkStockSufficiency, deductBySale } from '../src/modules/inventory/movements-service'
import AppError from '../src/utils/app-error'

// Utilidad para construir la cadena de metodos de Supabase (.from().select().in())
const mockChain = (resolvedValue) => {
  const chain = {
    select: jest.fn().mockReturnThis(),
    in:     jest.fn().mockReturnThis(),
    eq:     jest.fn().mockReturnThis(),
    insert: jest.fn().mockReturnThis(),
    update: jest.fn().mockReturnThis(),
    single: jest.fn().mockResolvedValue(resolvedValue),
  }
  // La cadena resuelve su promesa al final de la llamada
  chain.in.mockResolvedValue(resolvedValue)
  chain.select.mockResolvedValue(resolvedValue)
  return chain
}

// ─── Suite principal ──────────────────────────────────────────────────────────
describe('checkStockSufficiency — Validacion de stock antes de vender', () => {

  // ── Caso 1: stock suficiente ───────────────────────────────────────────────
  test('no lanza error cuando hay stock suficiente para todos los insumos', async () => {
    // Receta: 1 capuchino consume 0.02 kg de cafe y 0.15 l de leche
    // Stock disponible supera lo requerido
    supabase.from.mockReturnValue(
      mockChain({
        data: [
          {
            id_producto: 1,
            id_insumo: 1,
            cantidad_requerida: 0.02,
            insumos: { id_insumo: 1, nombre: 'Cafe molido', stock_actual: '1.000' },
          },
          {
            id_producto: 1,
            id_insumo: 2,
            cantidad_requerida: 0.15,
            insumos: { id_insumo: 2, nombre: 'Leche', stock_actual: '2.000' },
          },
        ],
        error: null,
      })
    )

    // Venta de 2 capuchinos: consume 0.04 kg cafe y 0.30 l leche — hay stock
    const items = [{ id_producto: 1, cantidad: 2 }]

    await expect(checkStockSufficiency(items)).resolves.toBeDefined()
  })

  // ── Caso 2: stock insuficiente en un insumo ────────────────────────────────
  test('lanza AppError 400 cuando un insumo no tiene stock suficiente', async () => {
    // Solo hay 0.01 kg de cafe, pero la receta requiere 0.02 kg por capuchino
    supabase.from.mockReturnValue(
      mockChain({
        data: [
          {
            id_producto: 1,
            id_insumo: 1,
            cantidad_requerida: 0.02,
            insumos: { id_insumo: 1, nombre: 'Cafe molido', stock_actual: '0.010' },
          },
        ],
        error: null,
      })
    )

    const items = [{ id_producto: 1, cantidad: 1 }]

    await expect(checkStockSufficiency(items)).rejects.toMatchObject({
      message: expect.stringContaining('Cafe molido'),
      statusCode: 400,
    })
  })

  // ── Caso 3: stock exactamente en el limite ─────────────────────────────────
  test('permite la venta cuando el stock disponible es exactamente igual al requerido', async () => {
    // Stock: 0.04 kg. Requerido para 2 capuchinos: 2 × 0.02 = 0.04 kg
    supabase.from.mockReturnValue(
      mockChain({
        data: [
          {
            id_producto: 1,
            id_insumo: 1,
            cantidad_requerida: 0.02,
            insumos: { id_insumo: 1, nombre: 'Cafe molido', stock_actual: '0.040' },
          },
        ],
        error: null,
      })
    )

    const items = [{ id_producto: 1, cantidad: 2 }]

    await expect(checkStockSufficiency(items)).resolves.toBeDefined()
  })

  // ── Caso 4: multiples productos con insumo compartido ─────────────────────
  test('acumula el consumo cuando varios productos usan el mismo insumo', async () => {
    // Americano y Capuchino comparten el insumo "Cafe molido"
    // Stock: 0.05 kg. Requerido: 0.02 + 0.03 = 0.05 kg — exacto, debe pasar
    supabase.from.mockReturnValue(
      mockChain({
        data: [
          {
            id_producto: 1,
            id_insumo: 1,
            cantidad_requerida: 0.02,
            insumos: { id_insumo: 1, nombre: 'Cafe molido', stock_actual: '0.050' },
          },
          {
            id_producto: 2,
            id_insumo: 1,
            cantidad_requerida: 0.03,
            insumos: { id_insumo: 1, nombre: 'Cafe molido', stock_actual: '0.050' },
          },
        ],
        error: null,
      })
    )

    const items = [
      { id_producto: 1, cantidad: 1 }, // consume 0.02
      { id_producto: 2, cantidad: 1 }, // consume 0.03
    ]

    await expect(checkStockSufficiency(items)).resolves.toBeDefined()
  })

  // ── Caso 5: multiples insumos insuficientes — mensaje incluye todos ────────
  test('el mensaje de error menciona todos los insumos insuficientes', async () => {
    supabase.from.mockReturnValue(
      mockChain({
        data: [
          {
            id_producto: 1,
            id_insumo: 1,
            cantidad_requerida: 0.5,
            insumos: { id_insumo: 1, nombre: 'Cafe molido', stock_actual: '0.100' },
          },
          {
            id_producto: 1,
            id_insumo: 2,
            cantidad_requerida: 0.3,
            insumos: { id_insumo: 2, nombre: 'Leche', stock_actual: '0.050' },
          },
        ],
        error: null,
      })
    )

    const items = [{ id_producto: 1, cantidad: 1 }]

    const error = await checkStockSufficiency(items).catch((e) => e)
    expect(error).toBeInstanceOf(AppError)
    expect(error.message).toContain('Cafe molido')
    expect(error.message).toContain('Leche')
    expect(error.statusCode).toBe(400)
  })

  // ── Caso 6: error de base de datos ────────────────────────────────────────
  test('lanza AppError 500 si Supabase devuelve un error al consultar recetas', async () => {
    supabase.from.mockReturnValue(
      mockChain({ data: null, error: { message: 'Connection refused' } })
    )

    const items = [{ id_producto: 1, cantidad: 1 }]

    await expect(checkStockSufficiency(items)).rejects.toMatchObject({
      statusCode: 500,
    })
  })

})

// ─── deductBySale ─────────────────────────────────────────────────────────────
describe('deductBySale — Descuento automatico de inventario al confirmar venta', () => {

  test('descuenta el stock correcto y registra movimiento salida_venta', async () => {
    // Primero checkStockSufficiency (consulta recetas)
    supabase.from
      .mockReturnValueOnce(
        mockChain({
          data: [
            {
              id_producto: 1,
              id_insumo: 1,
              cantidad_requerida: 0.02,
              insumos: { id_insumo: 1, nombre: 'Cafe molido', stock_actual: '1.000' },
            },
          ],
          error: null,
        })
      )
      // Luego update de stock
      .mockReturnValueOnce(mockChain({ data: {}, error: null }))
      // Luego insert de movimiento
      .mockReturnValueOnce(mockChain({ data: {}, error: null }))

    const items = [{ id_producto: 1, cantidad: 1 }]

    await expect(deductBySale(42, 7, items)).resolves.toBeUndefined()

    // Verifica que se haya llamado update y luego insert del movimiento
    expect(supabase.from).toHaveBeenCalledWith('receta')
    expect(supabase.from).toHaveBeenCalledWith('insumos')
    expect(supabase.from).toHaveBeenCalledWith('movimientos_inventario')
  })

  test('no altera el inventario cuando el stock es insuficiente', async () => {
    supabase.from.mockReturnValueOnce(
      mockChain({
        data: [
          {
            id_producto: 1,
            id_insumo: 1,
            cantidad_requerida: 1.0,
            insumos: { id_insumo: 1, nombre: 'Cafe molido', stock_actual: '0.100' },
          },
        ],
        error: null,
      })
    )

    const items = [{ id_producto: 1, cantidad: 1 }]
    await expect(deductBySale(99, 7, items)).rejects.toMatchObject({ statusCode: 400 })

    // El update de insumos NO debe haberse llamado
    const llamadasFrom = supabase.from.mock.calls.map((c) => c[0])
    expect(llamadasFrom).not.toContain('insumos')
  })

})
