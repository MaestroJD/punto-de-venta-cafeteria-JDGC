/**
 * Pruebas: Corte de caja (HU-13, HU-14, HU-15, T-24, T-25, T-26, T-38)
 *
 * Verifica apertura con monto inicial, bloqueo de doble apertura,
 * calculo de monto esperado, diferencia sobrante/faltante y
 * trazabilidad de usuario y timestamp en cada operacion.
 */

jest.mock('../src/config/supabase-client')

import supabase from '../src/config/supabase-client'
import {
  openCashRegister,
  closeCashRegister,
  getCashRegisterById,
  getOpenCashRegister,
} from '../src/modules/cash-register/cash-register-service'

// ─── Factory de cadenas Supabase mock ────────────────────────────────────────
function makeChain(data, error = null) {
  const chain = {
    select:      jest.fn().mockReturnThis(),
    insert:      jest.fn().mockReturnThis(),
    update:      jest.fn().mockReturnThis(),
    eq:          jest.fn().mockReturnThis(),
    gte:         jest.fn().mockReturnThis(),
    lte:         jest.fn().mockReturnThis(),
    order:       jest.fn().mockReturnThis(),
    single:      jest.fn().mockResolvedValue({ data, error }),
    maybeSingle: jest.fn().mockResolvedValue({ data, error }),
  }
  // Para consultas que no terminan en single/maybeSingle
  chain.order.mockResolvedValue({ data, error })
  chain.eq.mockResolvedValue({ data, error })
  return chain
}

// ─── openCashRegister ─────────────────────────────────────────────────────────
describe('openCashRegister — Apertura de caja (HU-13)', () => {

  test('crea un registro de caja con estado "abierta" y el monto inicial declarado', async () => {
    // No hay caja abierta previa
    supabase.from
      .mockReturnValueOnce(makeChain(null))              // maybeSingle → sin caja activa
      .mockReturnValueOnce({
        ...makeChain({ id_corte: 1, id_usuario: 5, monto_inicial: 300, estado: 'abierta', fecha_apertura: new Date().toISOString() }),
        insert: jest.fn().mockReturnThis(),
        select: jest.fn().mockReturnThis(),
        single: jest.fn().mockResolvedValue({
          data: { id_corte: 1, id_usuario: 5, monto_inicial: 300, estado: 'abierta', fecha_apertura: new Date().toISOString() },
          error: null,
        }),
      })

    const resultado = await openCashRegister(5, 300)

    expect(resultado.estado).toBe('abierta')
    expect(Number(resultado.monto_inicial)).toBe(300)
    expect(resultado.id_usuario).toBe(5)
  })

  test('incluye fecha_apertura en el registro de la caja', async () => {
    const fechaAntes = new Date().toISOString()

    supabase.from
      .mockReturnValueOnce(makeChain(null))
      .mockReturnValueOnce({
        insert: jest.fn().mockReturnThis(),
        select: jest.fn().mockReturnThis(),
        single: jest.fn().mockResolvedValue({
          data: {
            id_corte: 2,
            id_usuario: 3,
            monto_inicial: 0,
            estado: 'abierta',
            fecha_apertura: new Date().toISOString(),
          },
          error: null,
        }),
      })

    const resultado = await openCashRegister(3, 0)
    const fechaDespues = new Date().toISOString()

    expect(resultado.fecha_apertura).toBeDefined()
    expect(resultado.fecha_apertura >= fechaAntes).toBe(true)
    expect(resultado.fecha_apertura <= fechaDespues).toBe(true)
  })

  test('permite abrir caja con monto inicial de $0', async () => {
    supabase.from
      .mockReturnValueOnce(makeChain(null))
      .mockReturnValueOnce({
        insert: jest.fn().mockReturnThis(),
        select: jest.fn().mockReturnThis(),
        single: jest.fn().mockResolvedValue({
          data: { id_corte: 3, monto_inicial: 0, estado: 'abierta' },
          error: null,
        }),
      })

    const resultado = await openCashRegister(8, 0)
    expect(Number(resultado.monto_inicial)).toBe(0)
  })

  test('lanza AppError 409 si el cajero ya tiene una caja abierta (HU-13, segundo escenario)', async () => {
    // Hay una caja abierta previa
    supabase.from.mockReturnValueOnce({
      ...makeChain({ id_corte: 10, fecha_apertura: '2024-01-15T08:00:00Z', monto_inicial: 200 }),
      select:      jest.fn().mockReturnThis(),
      eq:          jest.fn().mockReturnThis(),
      maybeSingle: jest.fn().mockResolvedValue({
        data: { id_corte: 10, fecha_apertura: '2024-01-15T08:00:00Z', monto_inicial: 200 },
        error: null,
      }),
    })

    await expect(openCashRegister(5, 300)).rejects.toMatchObject({
      statusCode: 409,
      message: expect.stringContaining('10'), // menciona el id de la caja activa
    })
  })

  test('lanza AppError 409 con el id de la caja activa en el mensaje', async () => {
    supabase.from.mockReturnValueOnce({
      select:      jest.fn().mockReturnThis(),
      eq:          jest.fn().mockReturnThis(),
      maybeSingle: jest.fn().mockResolvedValue({
        data: { id_corte: 77, fecha_apertura: '2024-06-01T09:00:00Z', monto_inicial: 500 },
        error: null,
      }),
    })

    const error = await openCashRegister(5, 100).catch((e) => e)
    expect(error.statusCode).toBe(409)
    expect(error.message).toMatch(/77/) // el mensaje debe incluir el id de la caja activa
  })

})

// ─── closeCashRegister ────────────────────────────────────────────────────────
describe('closeCashRegister — Cierre de caja (HU-14)', () => {

  test('calcula monto_esperado = monto_inicial + suma de ventas en efectivo del turno', async () => {
    supabase.from
      // 1. Obtener corte de caja
      .mockReturnValueOnce({
        select:      jest.fn().mockReturnThis(),
        eq:          jest.fn().mockReturnThis(),
        maybeSingle: jest.fn().mockResolvedValue({
          data: { id_corte: 1, id_usuario: 5, monto_inicial: '200.00', estado: 'abierta' },
          error: null,
        }),
      })
      // 2. Obtener ventas en efectivo del turno
      .mockReturnValueOnce({
        select: jest.fn().mockReturnThis(),
        eq:     jest.fn().mockReturnThis(),
        // Segunda llamada a eq (estado=confirmada)
        mockReturnThis: jest.fn(),
      })

    // Ventas en efectivo: $150.00 + $80.50 = $230.50
    // Monto esperado = $200.00 + $230.50 = $430.50
    supabase.from
      .mockReturnValueOnce({
        select:      jest.fn().mockReturnThis(),
        eq:          jest.fn().mockReturnThis(),
        maybeSingle: jest.fn().mockResolvedValue({
          data: { id_corte: 1, id_usuario: 5, monto_inicial: '200.00', estado: 'abierta' },
          error: null,
        }),
      })
      .mockReturnValueOnce({
        select: jest.fn().mockReturnThis(),
        eq: jest.fn().mockReturnThis(),
        // Esta es la consulta de ventas - termina en una resolucion directa
        then: undefined,
      })

    // Redefinicion limpia con jest.fn encadenados correctamente
    supabase.from.mockReset()
    supabase.from
      // corte_caja
      .mockReturnValueOnce({
        select:      jest.fn().mockReturnThis(),
        eq:          jest.fn().mockReturnThis(),
        maybeSingle: jest.fn().mockResolvedValue({
          data: { id_corte: 1, id_usuario: 5, monto_inicial: '200.00', estado: 'abierta' },
          error: null,
        }),
      })
      // ventas del turno
      .mockReturnValueOnce({
        select: jest.fn().mockReturnThis(),
        eq: jest.fn().mockImplementation(() => ({
          eq: jest.fn().mockResolvedValue({
            data: [
              { monto_efectivo: '150.00' },
              { monto_efectivo: '80.50' },
            ],
            error: null,
          }),
        })),
      })
      // update corte_caja
      .mockReturnValueOnce({
        update: jest.fn().mockReturnThis(),
        eq:     jest.fn().mockReturnThis(),
        select: jest.fn().mockReturnThis(),
        single: jest.fn().mockResolvedValue({
          data: {
            id_corte: 1,
            monto_inicial:   200.00,
            monto_esperado:  430.50,
            monto_declarado: 430.50,
            diferencia:      0,
            estado: 'cerrada',
          },
          error: null,
        }),
      })

    const resultado = await closeCashRegister(1, 5, 430.50, 'cajero')

    expect(Number(resultado.monto_esperado)).toBe(430.50)
    expect(resultado.estado).toBe('cerrada')
  })

  test('calcula diferencia negativa (faltante) cuando el cajero declara menos de lo esperado', async () => {
    supabase.from
      .mockReturnValueOnce({
        select:      jest.fn().mockReturnThis(),
        eq:          jest.fn().mockReturnThis(),
        maybeSingle: jest.fn().mockResolvedValue({
          data: { id_corte: 2, id_usuario: 5, monto_inicial: '500.00', estado: 'abierta' },
          error: null,
        }),
      })
      .mockReturnValueOnce({
        select: jest.fn().mockReturnThis(),
        eq: jest.fn().mockImplementation(() => ({
          eq: jest.fn().mockResolvedValue({ data: [{ monto_efectivo: '300.00' }], error: null }),
        })),
      })
      .mockReturnValueOnce({
        update: jest.fn().mockReturnThis(),
        eq:     jest.fn().mockReturnThis(),
        select: jest.fn().mockReturnThis(),
        single: jest.fn().mockResolvedValue({
          data: {
            monto_esperado:  800.00,
            monto_declarado: 750.00,
            diferencia:      -50.00,  // FALTANTE
            estado: 'cerrada',
          },
          error: null,
        }),
      })

    const resultado = await closeCashRegister(2, 5, 750.00, 'cajero')
    expect(Number(resultado.diferencia)).toBeLessThan(0)
    expect(Math.abs(Number(resultado.diferencia))).toBe(50.00)
  })

  test('calcula diferencia positiva (sobrante) cuando el cajero declara mas de lo esperado', async () => {
    supabase.from
      .mockReturnValueOnce({
        select:      jest.fn().mockReturnThis(),
        eq:          jest.fn().mockReturnThis(),
        maybeSingle: jest.fn().mockResolvedValue({
          data: { id_corte: 3, id_usuario: 5, monto_inicial: '100.00', estado: 'abierta' },
          error: null,
        }),
      })
      .mockReturnValueOnce({
        select: jest.fn().mockReturnThis(),
        eq: jest.fn().mockImplementation(() => ({
          eq: jest.fn().mockResolvedValue({ data: [{ monto_efectivo: '200.00' }], error: null }),
        })),
      })
      .mockReturnValueOnce({
        update: jest.fn().mockReturnThis(),
        eq:     jest.fn().mockReturnThis(),
        select: jest.fn().mockReturnThis(),
        single: jest.fn().mockResolvedValue({
          data: {
            monto_esperado:  300.00,
            monto_declarado: 315.00,
            diferencia:      15.00,  // SOBRANTE
            estado: 'cerrada',
          },
          error: null,
        }),
      })

    const resultado = await closeCashRegister(3, 5, 315.00, 'cajero')
    expect(Number(resultado.diferencia)).toBeGreaterThan(0)
  })

  test('lanza AppError 409 si la caja ya estaba cerrada', async () => {
    supabase.from.mockReturnValueOnce({
      select:      jest.fn().mockReturnThis(),
      eq:          jest.fn().mockReturnThis(),
      maybeSingle: jest.fn().mockResolvedValue({
        data: { id_corte: 9, id_usuario: 5, estado: 'cerrada' },
        error: null,
      }),
    })

    await expect(closeCashRegister(9, 5, 100, 'cajero')).rejects.toMatchObject({
      statusCode: 409,
    })
  })

  test('lanza AppError 404 si el corte no existe', async () => {
    supabase.from.mockReturnValueOnce({
      select:      jest.fn().mockReturnThis(),
      eq:          jest.fn().mockReturnThis(),
      maybeSingle: jest.fn().mockResolvedValue({ data: null, error: null }),
    })

    await expect(closeCashRegister(999, 5, 100, 'cajero')).rejects.toMatchObject({
      statusCode: 404,
    })
  })

  test('lanza AppError 403 si un cajero intenta cerrar la caja de otro cajero', async () => {
    supabase.from.mockReturnValueOnce({
      select:      jest.fn().mockReturnThis(),
      eq:          jest.fn().mockReturnThis(),
      maybeSingle: jest.fn().mockResolvedValue({
        data: { id_corte: 5, id_usuario: 99, estado: 'abierta' }, // pertenece al usuario 99
        error: null,
      }),
    })

    // idUsuario=7 (diferente al dueno=99), rol=cajero (no admin)
    await expect(closeCashRegister(5, 7, 200, 'cajero')).rejects.toMatchObject({
      statusCode: 403,
    })
  })

  test('un administrador puede cerrar la caja de cualquier cajero', async () => {
    supabase.from
      .mockReturnValueOnce({
        select:      jest.fn().mockReturnThis(),
        eq:          jest.fn().mockReturnThis(),
        maybeSingle: jest.fn().mockResolvedValue({
          data: { id_corte: 5, id_usuario: 99, monto_inicial: '100.00', estado: 'abierta' },
          error: null,
        }),
      })
      .mockReturnValueOnce({
        select: jest.fn().mockReturnThis(),
        eq: jest.fn().mockImplementation(() => ({
          eq: jest.fn().mockResolvedValue({ data: [], error: null }),
        })),
      })
      .mockReturnValueOnce({
        update: jest.fn().mockReturnThis(),
        eq:     jest.fn().mockReturnThis(),
        select: jest.fn().mockReturnThis(),
        single: jest.fn().mockResolvedValue({
          data: { id_corte: 5, monto_esperado: 100, monto_declarado: 100, diferencia: 0, estado: 'cerrada' },
          error: null,
        }),
      })

    // idUsuario=1 (admin, diferente al dueno=99), rol=administrador
    await expect(closeCashRegister(5, 1, 100, 'administrador')).resolves.toMatchObject({
      estado: 'cerrada',
    })
  })

})

// ─── Trazabilidad: usuario y timestamp ────────────────────────────────────────
describe('Trazabilidad — Operaciones de caja quedan asociadas al usuario (T-38)', () => {

  test('openCashRegister asocia el id_usuario al registro de caja', async () => {
    let datosInsertados = null

    supabase.from
      .mockReturnValueOnce({
        select:      jest.fn().mockReturnThis(),
        eq:          jest.fn().mockReturnThis(),
        maybeSingle: jest.fn().mockResolvedValue({ data: null, error: null }),
      })
      .mockReturnValueOnce({
        insert: jest.fn().mockImplementation((data) => {
          datosInsertados = data
          return {
            select: jest.fn().mockReturnThis(),
            single: jest.fn().mockResolvedValue({
              data: { ...data, id_corte: 1 },
              error: null,
            }),
          }
        }),
      })

    await openCashRegister(42, 500)

    expect(datosInsertados).not.toBeNull()
    expect(datosInsertados.id_usuario).toBe(42)
  })

  test('getOpenCashRegister devuelve null si el cajero no tiene caja abierta', async () => {
    supabase.from.mockReturnValueOnce({
      select:      jest.fn().mockReturnThis(),
      eq:          jest.fn().mockReturnThis(),
      maybeSingle: jest.fn().mockResolvedValue({ data: null, error: null }),
    })

    const resultado = await getOpenCashRegister(5)
    expect(resultado).toBeNull()
  })

  test('getOpenCashRegister devuelve la caja activa del cajero', async () => {
    const cajaActiva = { id_corte: 8, id_usuario: 5, estado: 'abierta', monto_inicial: 250 }

    supabase.from.mockReturnValueOnce({
      select:      jest.fn().mockReturnThis(),
      eq:          jest.fn().mockReturnThis(),
      maybeSingle: jest.fn().mockResolvedValue({ data: cajaActiva, error: null }),
    })

    const resultado = await getOpenCashRegister(5)
    expect(resultado).toEqual(cajaActiva)
    expect(resultado.estado).toBe('abierta')
  })

})
